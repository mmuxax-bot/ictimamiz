//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_lR4s-L.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/admin"],
		preloads: [
			"/assets/index-4OIIM3oM.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/store-YH8BF7U3.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-4OIIM3oM.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BA02QX2D.js", "/assets/use-today-BZq9WnKq.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-vvhHKL9J.js", "/assets/use-today-BZq9WnKq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
