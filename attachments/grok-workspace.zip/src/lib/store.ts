import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { isoWeekId } from "@/lib/week";

export type AttendanceStatus = "present" | "excused" | "unexcused";

export type Person = {
  id: string;
  name: string;
  createdAt: number;
};

export type Hadith = {
  id: string;
  text: string;
  source: string;
};

export type AttendanceRecord = {
  personId: string;
  weekId: string;
  day: number;
  status: AttendanceStatus;
};

export const ADMIN_CODE = "admin 26";
export const STORAGE_KEY = "meclis-qayib-v1";
export const ADMIN_SESSION_KEY = "meclis-admin-session";

export const SEED_HADITHS: Hadith[] = [
  {
    id: "h1",
    text: "Əməllər ancaq niyyətlərə görədir. Hər kəsə niyyət etdiyi şey nəsib olar.",
    source: "Buxari, Müslim",
  },
  {
    id: "h2",
    text: "Heç biriniz iman gətirmiş olmaz ki, özü üçün istədiyini din qardaşı üçün də istəməsin.",
    source: "Buxari, Müslim",
  },
  {
    id: "h3",
    text: "Müsəlman o kəsdir ki, müsəlmanlar onun əlindən və dilindən salamat qalsınlar.",
    source: "Buxari",
  },
  {
    id: "h4",
    text: "Allahın yanında ən sevimli əməl davamlı olanıdır — az olsa belə.",
    source: "Buxari, Müslim",
  },
  {
    id: "h5",
    text: "Təbəssüm etmək də sədəqədir.",
    source: "Tirmizi",
  },
];

type ActionResult = { ok: true } | { ok: false; error: string };

type AppState = {
  people: Person[];
  hadiths: Hadith[];
  records: AttendanceRecord[];
  hasHydrated: boolean;
  setHasHydrated: (value: boolean) => void;
  addPerson: (name: string) => ActionResult;
  removePerson: (id: string) => void;
  addHadith: (text: string, source: string) => ActionResult;
  removeHadith: (id: string) => void;
  setAttendance: (
    personId: string,
    weekId: string,
    day: number,
    status: AttendanceStatus | null,
  ) => void;
};

function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

const noopStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      people: [],
      hadiths: SEED_HADITHS,
      records: [],
      hasHydrated: false,
      setHasHydrated: (value) => set({ hasHydrated: value }),
      addPerson: (rawName) => {
        const name = rawName.trim().replace(/\s+/g, " ");
        if (!name) return { ok: false, error: "Ad boş ola bilməz." };
        const exists = get().people.some(
          (p) => p.name.localeCompare(name, "az", { sensitivity: "accent" }) === 0,
        );
        if (exists) return { ok: false, error: "Bu ad artıq siyahıdadır." };
        set({
          people: [
            ...get().people,
            { id: newId(), name, createdAt: Date.now() },
          ].sort((a, b) => a.name.localeCompare(b.name, "az")),
        });
        return { ok: true };
      },
      removePerson: (id) => {
        set({
          people: get().people.filter((p) => p.id !== id),
          records: get().records.filter((r) => r.personId !== id),
        });
      },
      addHadith: (rawText, rawSource) => {
        const text = rawText.trim();
        const source = rawSource.trim();
        if (!text) return { ok: false, error: "Hədis mətni boş ola bilməz." };
        set({
          hadiths: [
            ...get().hadiths,
            { id: newId(), text, source: source || "Əlavə olunub" },
          ],
        });
        return { ok: true };
      },
      removeHadith: (id) => {
        set({ hadiths: get().hadiths.filter((h) => h.id !== id) });
      },
      setAttendance: (personId, weekId, day, status) => {
        const rest = get().records.filter(
          (r) => !(r.personId === personId && r.weekId === weekId && r.day === day),
        );
        if (!status) {
          set({ records: rest });
          return;
        }
        set({ records: [...rest, { personId, weekId, day, status }] });
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? noopStorage : localStorage,
      ),
      partialize: (state) => ({
        people: state.people,
        hadiths: state.hadiths,
        records: state.records,
      }),
      skipHydration: true,
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);

export function findRecord(
  records: AttendanceRecord[],
  personId: string,
  weekId: string,
  day: number,
): AttendanceRecord | undefined {
  return records.find(
    (r) => r.personId === personId && r.weekId === weekId && r.day === day,
  );
}

export type AbsenteeRank = {
  person: Person;
  unexcused: number;
  excused: number;
  present: number;
  absences: number;
};

export function rankAbsentees(
  people: Person[],
  records: AttendanceRecord[],
  weekId?: string,
): AbsenteeRank[] {
  const scoped = weekId ? records.filter((r) => r.weekId === weekId) : records;
  return people
    .map((person) => {
      const mine = scoped.filter((r) => r.personId === person.id);
      const unexcused = mine.filter((r) => r.status === "unexcused").length;
      const excused = mine.filter((r) => r.status === "excused").length;
      const present = mine.filter((r) => r.status === "present").length;
      return {
        person,
        unexcused,
        excused,
        present,
        absences: unexcused + excused,
      };
    })
    .filter((row) => row.absences > 0)
    .sort(
      (a, b) =>
        b.unexcused - a.unexcused ||
        b.absences - a.absences ||
        a.person.name.localeCompare(b.person.name, "az"),
    );
}

export function currentWeekId(): string {
  return isoWeekId(new Date());
}
