import { useEffect, type ReactNode } from "react";
import { useAppStore } from "@/lib/store";

export function StoreProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    void useAppStore.persist.rehydrate();
    const timeout = window.setTimeout(() => {
      if (!useAppStore.getState().hasHydrated) {
        useAppStore.getState().setHasHydrated(true);
      }
    }, 80);
    return () => window.clearTimeout(timeout);
  }, []);

  return children;
}
